//import logo from './logo.svg';
import React from 'react';
import './assets/styles.css'
import './App.css';
import Header from './Header';
import Slider from './Slider';
import ButtonGroup from './components/buttonGroup';
import Dropdown from './components/Dropdown';
import Divider from "@material-ui/core/Divider";
import ProductTable from './components/ProductTable';
import { useMemo } from 'react'
import Table from './components/ReactTable';
import Badge from 'react-bootstrap/Badge';
import { Chip } from '@mui/material';
import { useState } from 'react';
import { useTable, useFilters } from "react-table";

function App() {

  const [data, setData] = React.useState(null);
  const [value, setValue] = useState(null)
  const [active, setActive] = useState([])
  const [active1, setActive1] = useState([])
  const [testorganismactive, settestorganismactive] = useState([])
  const [sourceactive, setsourceactive] = useState([])
  const [currentIndex, setCurrentIndex] = useState(0);


  const _handleIndexChange = (index) => {
    setCurrentIndex(index);
  };

  const handleChange = (event) => {
    const value = event.target.value || undefined;
    setValue(event.target.value);
  };

  const Dropdown = ({ options }) => {
    return (
      <select value={value} onChange={handleChange}>
        {options.map((option) => (
          <option value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    )
  }

  const ButtonGroup = (props) => {

    // const [active,setActive] = useState([])   
    // const BUTTONS = [ 'oral', 'inhalation', 'topical']

    return props.items.map(key => {
      const isActive = active.includes(key)

      return (
        <button
          key={key}
          className="px-2"
          onClick={() => setActive(isActive
            ? active.filter(current => current !== key)
            : [...active, key]
          )}
          style={{
            background: isActive ? 'blue' : 'white',
            borderWidth: 1,
            borderRadius: 5,
            display: 'inline-block',
            margin: 5
          }}
        >
          {key}
        </button>
      )
    })

  }


  const ButtonGroup1 = (props) => {

    // const [active,setActive] = useState([])   
    // const BUTTONS = [ 'oral', 'inhalation', 'topical']

    return props.items.map(key => {
      const isActive = active1.includes(key)

      return (
        <button
          key={key}
          className="px-2"
          onClick={() => setActive1(isActive
            ? active1.filter(current => current !== key)
            : [...active1, key]
          )}
          style={{
            background: isActive ? 'blue' : 'white',
            borderWidth: 1,
            borderRadius: 5,
            display: 'inline-block',
            margin: 5
          }}
        >
          {key}
        </button>
      )
    })

  }

  const ButtonGrouptest = (props) => {

    // const [active,setActive] = useState([])   
    // const BUTTONS = [ 'oral', 'inhalation', 'topical']

    return props.items.map(key => {
      const isActive = testorganismactive.includes(key)

      return (
        <button
          key={key}
          className="px-2"
          onClick={() => settestorganismactive(isActive
            ? testorganismactive.filter(current => current !== key)
            : [...testorganismactive, key]
          )}
          style={{
            background: isActive ? 'blue' : 'white',
            borderWidth: 1,
            borderRadius: 5,
            display: 'inline-block',
            margin: 5
          }}
        >
          {key}
        </button>
      )
    })

  }
  const ButtonGroupsource = (props) => {

    // const [active,setActive] = useState([])   
    // const BUTTONS = [ 'oral', 'inhalation', 'topical']

    return props.items.map(key => {
      const isActive = sourceactive.includes(key)

      return (
        <button
          key={key}
          className="px-2"
          onClick={() => setsourceactive(isActive
            ? sourceactive.filter(current => current !== key)
            : [...sourceactive, key]
          )}
          style={{
            background: isActive ? 'blue' : 'white',
            borderWidth: 1,
            borderRadius: 5,
            display: 'inline-block',
            margin: 5
          }}
        >
          {key}
        </button>
      )
    })

  }



  React.useEffect(() => {
    //  fetch(process.env.REACT_APP_BACKEND_URL)
    fetch("http://localhost:4000/")
      .then((res) => res.json())
      .then((data) => setData(data));
    console.log(data)
  }, []);




  const tabledata = useMemo(
    () => [
      {
        Header: "SUPPLEMENT",
        accessor: "name",
        width: 120,
      },
      {
        Header: "OTHER NAMES",
        accessor: "othername"
      },
      {
        Header: "EVIDENCE FOR ANTI-AGEING",
        accessor: "level",
        Cell: ({ cell: { value } }) => <label className=' space-x-1 space-y-1'><Levels values={value} /></label>

      },
      {
        Header: "ALSO GOOD FOR",
        accessor: "alsogoodfor",
        width: 350,
        Cell: ({ cell: { value } }) => <label className=' space-x-1 space-y-1'><Genres values={value} color='primary' /></label>

      },
      {
        Header: "ADMINISTRATION",
        accessor: "administration",
        Cell: ({ cell: { value } }) => <label className=' space-x-1 space-y-1'><Genres values={value} color='secondary' /></label>
      },

      {
        Header: "TEST ORGANISMS",
        accessor: "testorganism",
        Cell: ({ cell: { value } }) => <label className=' space-x-1 space-y-1'><Genres values={value} color='success' /></label>
      },

      {
        Header: "COMPOUND SOURCES",
        accessor: "compoundsource",
        Cell: ({ cell: { value } }) => <label className=' space-x-1 space-y-1'><Genres values={value} color='warning' /></label>
      },
    ],
    []
  );

  const Genres = ({ values, color }) => {
    // console.log(values)
    if (values != null)
      return (
        <>
          {
            values.map((genre, idx) => {
              return (
                <Chip label={genre} size="small" color={color} variant="outlined" key={idx} />
              );
            })}
        </>
      );
  };

  const Levels = ({ values }, idx) => {
    return (
      <>
        <Chip label={values} size="small" color="primary" variant="" key={idx} />
      </>
    );
  }


  return (
    <React.Fragment>
      <Header />


      {/* <div>{data.names}</div> */}
      <section className='lg:mx-auto md:mx-5 max-w-[120rem]'>

        <div className='center-component'>
          <div className='column'>
            <div>Level of evidence for anti-ageing property</div>
            <div className='administration flex items-center justify-between'>
              <ButtonGroup1 items={['High', 'Medium', 'Low']} />
            </div>

            {/* <Slider/> */}
          </div>

          <div className='column'>
            <div>Administration</div>
            <div className='administration'>
              <ButtonGroup items={['Oral', 'Inhalation',]} />
            </div>

            <div className='administration'>
              <ButtonGroup items={['Topical', 'Rectal']} />
            </div>

            <div className='administration'>
              <ButtonGroup items={['Subcutaneoes Implant', 'IV',]} />
            </div>

          </div>


          <div className='column'>
            <div>Test Organism</div>
            <ButtonGrouptest items={['Human', 'Primate', 'Mammal', 'Human Cell Line', 'Vertebrae', 'Other']} />
          </div>

        </div>

        <div className='center-component'>

          <div className='column'>
            <div>Also good for</div>
            <Dropdown
              className='p-4 border rounded-sm border-gray-700'
              options={[
                { value: '', label: '--Choose an option--', disabled: true },
                { label: 'Blood Clot', value: 'Blood Clot' },
                { label: 'Inflammation', value: 'Inflammation' },
                { label: 'Cancer', value: 'Cancer' },

              ]}
            //   <option disabled={true} value="">
            //   --Choose and option--
            // </option>

            />
          </div>

          <div className='column'>
            <div style={{ alignSelf: 'center' }}>Compound Source</div>
            <div className='administration'>
              <ButtonGroupsource items={['Natural', 'Synthetically produced', 'Synthetically designed']} />
            </div>
          </div>

          <div className='column'>
            <div></div>

          </div>


        </div>
        <br />
        <Divider />

        <div className='tableWrap'>
          <br /> <br />
          {data && <Table columns={tabledata} data={data} value={value} active={active} active1={active1} testorganismactive={testorganismactive} sourceactive={sourceactive} />
          }
        </div>
      </section>


    </React.Fragment>

  );
}

export default App;
